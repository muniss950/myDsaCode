#include<stdio.h>
//#pragma pack(1)
struct a
{
	int a;
	char b;//5 - 8
};
struct b
{
	int a;
	int b;
	char c;//9 - 12
};
struct c
{
	float d;
	int e;
	char f;
	double g;//17 - 24
};
struct d
{
	int g;
	double h;//12 - 16
};
int main()
{
	printf("Size of struct a is %ld \n ", sizeof(struct a));
	printf("Size of struct b is %ld \n ", sizeof(struct b));
	printf("Size of struct c is %ld \n ", sizeof(struct c));
	printf("Size of struct d is %ld \n ", sizeof(struct d));
	return 0;
}
