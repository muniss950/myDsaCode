// Structure : Heterogeneous collection of data elements
// Syntax: struct name
// 	{
		// Data memmbers ( DT vars);
// 	};
#include<stdio.h>
#include<string.h>
struct student
{
	int rno;
	char name[20];
	float rno;
};
int main()
{
	
	struct student s1 = {.name="PESU",.marks=65,.rno=9};
	printf("Size of struct is %ld\n", sizeof(s1));
	printf("Roll No is %d\n", s1.rno);
	printf("Name is %s\n", s1.name);
	printf("Marks is %d\n", s1.marks);
	
	
}
