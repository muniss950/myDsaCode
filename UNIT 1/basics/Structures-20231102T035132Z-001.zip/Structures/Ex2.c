#include<stdio.h>
struct test
{
	int i;
	char c;
};
int main()
{
	struct test t1={2,'A'};
	struct test t2=t1;
	printf("Address of t1 is %p\n", &t1);
	printf("Add of t2 is %p\n", &t2);
	if(t1.i==t2.i && t1.c==t2.c)
	printf("Equal...\n");
	else
	printf("not Equal...\n");
	printf(" T1.i is %d\n", t1.i);
	printf(" T2.i is %d\n", t2.i);
	printf(" T1.c is %c\n", t1.c);
	printf(" T2.c is %c\n", t2.c);
	t2.c='B';
	printf(" T1.i is %d\n", t1.i);
	printf(" T2.i is %d\n", t2.i);
	printf(" T1.c is %c\n", t1.c);
	printf(" T2.c is %c\n", t2.c);
	t1.i=3;
	printf(" T1.i is %d\n", t1.i);
	printf(" T2.i is %d\n", t2.i);
	printf(" T1.c is %c\n", t1.c);
	printf(" T2.c is %c\n", t2.c);
	
}
