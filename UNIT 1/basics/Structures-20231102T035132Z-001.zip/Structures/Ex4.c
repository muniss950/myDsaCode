#include<stdio.h>
#include<string.h>
struct test
{
	int i;
	char a[20];
	float j;
};
void f1(struct test t1);
void f2(struct test *t1);
int main()
{
	struct test t1={9,"PES",9.8f};
	printf("%s\n", t1.a);
	f1(t1);
	printf("%s\n", t1.a);
	f2(&t1);
	printf("%s\n", t1.a);	
}
void f1(struct test t1)
{
	strcpy(t1.a,"PESU");
}
void f2(struct test *t1)
{
	strcpy(t1->a,"PESU");
}

