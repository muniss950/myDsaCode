//malloc : one single of memory
//Syntax : ptr=(cast) malloc(size_t cast);
//stdlib.h
// Success : return a pointer of type void (void*) -> cast -> cast_type
// failure : NULL
#include<stdio.h>
#include<stdlib.h>
int main()
{
	int *ptr,i,n;
	printf("Address of ptr is %p\n", ptr);
	printf("Enter the value of n\n");
	scanf("%d",&n);
	ptr = (int*)malloc(n*sizeof(int));
	printf("Address of ptr is %p\n", ptr);
	if(ptr==NULL)
	{
		printf("M/y cannot be allocated..\n");
		return 0;
	}
	else
	{
		printf("READ VALUES...\n");
		for(i=0;i<n;i++)
		scanf("%d",(ptr+i));
		
		printf("DISPLAY VALUES...\n");
		for(i=0;i<n;i++)
		printf("%d",*(ptr+i));
		
	}
	
}

