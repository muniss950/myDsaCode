//re- alloc : reallocates the existing block created by malloc / calloc
//Syntax : ptr=(cast) calloc(n, size_t cast);
		//realloc();
	//ptr=(cast)realloc(old_ptr, size_t cast);
// Success : return a pointer of type void (void*) -> cast -> cast_type
// failure : NULL
//stdlib.h
#include<stdio.h>
#include<stdlib.h>
int main()
{
	int *ptr,i,n,r;
	printf("Address of ptr is %p\n", ptr);
	printf("Enter the value of n\n");
	scanf("%d",&n);
	ptr = (int*)calloc(n, n*sizeof(int));
	printf("Address of ptr is %p\n", ptr);
	if(ptr==NULL)
	{
		printf("M/y cannot be allocated..\n");
		return 0;
	}
	else
	{

		printf("DEFAULT VALUES...\n");
		for(i=0;i<n;i++)
		printf("%d",*(ptr+i));

		printf("READ VALUES...\n");
		for(i=0;i<n;i++)
		scanf("%d",(ptr+i));
		
		printf("DISPLAY VALUES...\n");
		for(i=0;i<n;i++)
		printf("%d",*(ptr+i));
		
	}
	printf("By how much memory do u want to increase..\n");
	scanf("%d",&r);
	ptr=(int*)realloc(ptr,(n+r)*sizeof(int));

	printf("READ VALUES...\n");
	for(i=0;i<r;i++)
	scanf("%d",(ptr+i+n));
		
	printf("DISPLAY VALUES...\n");
	for(i=0;i<(n+r);i++)
	printf("%d",*(ptr+i));
	printf("\n");

	free(ptr);
	for(i=0;i<n+r;i++)
	printf("%d",*(ptr));
	printf("Address of ptr is %p\n", ptr);
	printf("\n");
	
	/*ptr=NULL;
	for(i=0;i<n;i++)
	printf("%d",*(ptr));
	printf("Address of ptr is %p\n", ptr);*/
	
}

