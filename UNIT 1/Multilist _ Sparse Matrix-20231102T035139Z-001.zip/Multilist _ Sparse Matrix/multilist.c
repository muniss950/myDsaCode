#include"multilist.h"

int main()
{
	LIST *l;
	
	initList(&l);
	createList(&l);
	display(&l);
}